// Set up the camera for a given video element
function setupCamera(videoId) {
    const video = document.getElementById(videoId);
    if (video) {
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(stream => video.srcObject = stream)
            .catch(err => {
                console.error('Error accessing the camera:', err);
                alert('Please enable camera access.');
            });
    }
}

// Capture an image from the video stream, compress it, and store it as base64
function captureImage(type) {
    const video = document.getElementById(`${type}Video`);
    const canvas = document.getElementById(`${type}Canvas`);
    const capturedImage = document.getElementById(`${type}CapturedImage`);
    const faceDataInput = document.getElementById(`${type}FaceData`);

    if (video && canvas && capturedImage && faceDataInput) {
        canvas.width = 160;
        canvas.height = 160;
        const context = canvas.getContext('2d');
        context.drawImage(video, 0, 0, canvas.width, canvas.height);

        const dataURL = canvas.toDataURL('image/jpeg', 0.5);
        faceDataInput.value = dataURL;
        capturedImage.src = dataURL;
        capturedImage.classList.remove('hidden');
        alert('Image captured successfully!');
    }
}

// Initialize cameras and handle form submissions
document.addEventListener('DOMContentLoaded', function () {
    setupCamera('registerVideo');  // Initialize camera for registration page
    setupCamera('loginVideo');     // Initialize camera for login page
    setupCamera('checkoutVideo');  // Initialize camera for checkout page

    // Handle Registration Form Submission
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function (event) {
            event.preventDefault();

            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value.trim();
            const face_data = document.getElementById('registerFaceData').value.trim();

            if (!name || !email || !password || !face_data) {
                alert('All fields are required.');
                return;
            }

            const paymentMethodElements = registerForm.querySelectorAll('.payment-method');
            const payment_methods = Array.from(paymentMethodElements).map((method) => ({
                card_number: method.querySelector('.card_number').value.trim(),
                bank_name: method.querySelector('.bank_name').value.trim(),
                card_type: method.querySelector('.card_type').value.trim(),
                expiry_date: method.querySelector('.expiry_date').value.trim(),
            }));

            for (let i = 0; i < payment_methods.length; i++) {
                const method = payment_methods[i];
                if (!method.card_number || !method.bank_name || !method.card_type || !method.expiry_date) {
                    alert(`All fields are required for Payment Method ${i + 1}.`);
                    return;
                }
            }

            fetch('/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, password, face_data, payment_methods }),
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    window.location.href = data.redirect_url;
                } else {
                    alert(data.message);
                }
            })
            .catch(error => console.error('Registration Error:', error));
        });
    }

    // Handle Login Form Submission
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function (event) {
            event.preventDefault();

            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value.trim();
            const face_data = document.getElementById('loginFaceData').value.trim();

            if (!email || !password || !face_data) {
                alert('All fields are required.');
                return;
            }

            const formData = new FormData();
            formData.append('email', email);
            formData.append('password', password);
            formData.append('face_data', face_data);

            fetch('/login', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    window.location.href = data.redirect_url;
                } else {
                    alert(data.message);
                }
            })
            .catch(error => console.error('Login Error:', error));
        });
    }

    // Initialize Stripe with your public key
    const stripe = Stripe('pk_test_51Q2ZGH055NWWURZmMYzpSCeGbpopSdeTMQOSC3IcDxFLqfb1C7UwiHpliIJNUre3MJqLTx9rdEMqXXY3gFaAHPGr00RyC1Uz7G');
    const elements = stripe.elements();
    const cardElement = elements.create('card');
    cardElement.mount('#card-element');

    // Show payment form after face verification
    async function showPaymentForm() {
        const paymentForm = document.getElementById('payment-form');
        paymentForm.classList.remove('hidden');

        const response = await fetch('/payment_intent', { method: 'POST', headers: { 'Content-Type': 'application/json' } });
        const data = await response.json();

        if (data.client_secret) {
            document.getElementById('stripeForm').addEventListener('submit', async (event) => {
                event.preventDefault();
                const { error } = await stripe.confirmCardPayment(data.client_secret, { payment_method: { card: cardElement } });

                if (error) {
                    alert(`Payment failed: ${error.message}`);
                } else {
                    alert('Payment successful!');
                    window.location.href = '/payment_success';
                }
            });
        } else {
            alert('Error creating payment intent.');
        }
    }

    // Verify face and show payment form if successful
    async function verifyFace() {
        const userId = document.getElementById('userId').value;
        const faceData = document.getElementById('checkoutFaceData').value.trim();
        const formData = new FormData();
        formData.append('user_id', userId);
        formData.append('face_data', faceData);

        const response = await fetch('/checkout_verification', { method: 'POST', body: formData });
        const data = await response.json();

        if (data.status === 'success') {
            alert('Face verification successful!');
            showPaymentForm();
        } else {
            alert(data.message || 'Face verification failed.');
        }
    }

    document.getElementById('verifyFaceButton').addEventListener('click', verifyFace);
});
