import sqlite3
import time

def connect_db_with_retry(retries=5, delay=1):
    """Attempt to connect to the database, retrying if the database is locked."""
    for i in range(retries):
        try:
            conn = sqlite3.connect('user_face_data.db')
            return conn
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e):
                print(f"Database is locked, retrying... ({i+1}/{retries})")
                time.sleep(delay)
            else:
                raise e
    raise sqlite3.OperationalError("Database is still locked after retries.")

def initialize_db():
    """Create the necessary tables in the database."""
    with connect_db_with_retry() as conn:
        c = conn.cursor()
        # Create tables if they do not exist
        c.execute("CREATE TABLE IF NOT EXISTS user_info (id INTEGER PRIMARY KEY, name TEXT, email TEXT, password TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS face_embeddings (user_id INTEGER, encoding BLOB, FOREIGN KEY(user_id) REFERENCES user_info(id))")
        c.execute("CREATE TABLE IF NOT EXISTS payment_methods (id INTEGER PRIMARY KEY, user_id INTEGER, card_number TEXT, bank_name TEXT, card_type TEXT, expiry_date TEXT, FOREIGN KEY(user_id) REFERENCES user_info(id))")
        conn.commit()

def insert_user(name, email, password):
    """Insert a new user and return the user_id."""
    with connect_db_with_retry() as conn:
        c = conn.cursor()
        c.execute("INSERT INTO user_info (name, email, password) VALUES (?, ?, ?)", (name, email, password))
        conn.commit()
        return c.lastrowid

def insert_face_embedding(user_id, embedding_serialized):
    """Insert a face embedding for the user."""
    with connect_db_with_retry() as conn:
        c = conn.cursor()
        c.execute("INSERT INTO face_embeddings (user_id, encoding) VALUES (?, ?)", (user_id, embedding_serialized))
        conn.commit()

def insert_payment_method(user_id, card_number, bank_name, card_type, expiry_date):
    """Insert a payment method for a user."""
    with connect_db_with_retry() as conn:
        c = conn.cursor()
        c.execute("INSERT INTO payment_methods (user_id, card_number, bank_name, card_type, expiry_date) VALUES (?, ?, ?, ?, ?)",
                  (user_id, card_number, bank_name, card_type, expiry_date))
        conn.commit()

def load_user_by_email(email):
    """Load user information by email."""
    with connect_db_with_retry() as conn:
        c = conn.cursor()
        c.execute("SELECT id, name, email, password FROM user_info WHERE email = ?", (email,))
        return c.fetchone()

def load_face_embedding_by_user_id(user_id):
    """Load a face embedding by user_id."""
    with connect_db_with_retry() as conn:
        c = conn.cursor()
        c.execute("SELECT encoding FROM face_embeddings WHERE user_id = ?", (user_id,))
        result = c.fetchone()
        return result[0] if result else None

def load_payment_methods_by_user_id(user_id):
    """Load payment methods for a specific user."""
    with connect_db_with_retry() as conn:
        c = conn.cursor()
        c.execute("SELECT id, card_number, bank_name, card_type, expiry_date FROM payment_methods WHERE user_id = ?", (user_id,))
        rows = c.fetchall()
    return [{'id': row[0], 'card_number': row[1], 'bank_name': row[2], 'card_type': row[3], 'expiry_date': row[4]} for row in rows]
