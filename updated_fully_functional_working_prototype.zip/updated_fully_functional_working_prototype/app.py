from flask import session, Flask, render_template, request, jsonify, url_for, redirect
from datetime import datetime
import bcrypt
import base64
import cv2
import os
import numpy as np
from utils import detect_img, ext_face, face_embed, register_user, load_user_by_email, verify_face
from database import initialize_db, load_payment_methods_by_user_id
import stripe
from decimal import Decimal

app = Flask(__name__)
app.secret_key = os.urandom(24)
initialize_db()

stripe.api_key = "sk_test_51Q2ZGH055NWWURZmblCVBBHs71JCpyl72q8bb8r7bGGr4PfNWITfHwjjYrhuLXvWHbwjAh0HQkuOS1Ojo8I0lapL00qPg47n7K"

def decode_image(image_data):
    """Decode base64 image data to a usable NumPy array (BGR format for OpenCV)."""
    try:
        if ',' in image_data:
            _, base64_data = image_data.split(',', 1)
        else:
            base64_data = image_data
            
        image_bytes = base64.b64decode(base64_data)
        np_arr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        
        if img is None:
            raise ValueError("Decoded image is None. Check base64 encoding.")
        
        return img
    except Exception as e:
        print(f"Error decoding image: {e}")
        return None

@app.route('/')
def index():
    return render_template('welcome.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    
    try:
        data = request.get_json()
        name = data.get('name')
        email = data.get('email')
        password = data.get('password')
        face_data = data.get('face_data')
        payment_methods = data.get('payment_methods')

        if not (name and email and password and face_data and payment_methods):
            return jsonify({'status': 'fail', 'message': 'All fields are required'}), 400

        image = decode_image(face_data)
        if image is None:
            return jsonify({'status': 'fail', 'message': 'Invalid image data'}), 400

        faces = detect_img(image)
        if not faces:
            return jsonify({'status': 'fail', 'message': 'No face detected'}), 400
        
        face_image = ext_face(image, faces[0]['box'])
        embedding = face_embed(face_image)

        user_id = register_user(name, email, password, embedding, payment_methods)
        
        if user_id:
            return jsonify({'status': 'success', 'redirect_url': url_for('registration_success')})
        else:
            return jsonify({'status': 'fail', 'message': 'Registration failed. Please try again.'}), 500

    except Exception as e:
        print(f"Error during registration: {e}")
        return jsonify({'status': 'fail', 'message': 'Registration failed. Please try again.'}), 500

@app.route('/registration_success')
def registration_success():
    return render_template('success.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')

    try:
        email = request.form.get('email')
        password = request.form.get('password')
        face_data = request.form.get('face_data')

        user = load_user_by_email(email)
        if user is None:
            return jsonify({'status': 'fail', 'message': 'User not found. Please register.'}), 400
        
        user_id, name, _, stored_password = user
        if not bcrypt.checkpw(password.encode('utf-8'), stored_password):
            return jsonify({'status': 'fail', 'message': 'Invalid password'}), 400

        image = decode_image(face_data)
        if image is None:
            return jsonify({'status': 'fail', 'message': 'Invalid image data'}), 400

        if verify_face(user_id, image):
            session['user_id'] = user_id
            return jsonify({'status': 'success', 'redirect_url': url_for('products')})
        else:
            return jsonify({'status': 'fail', 'message': 'Face verification failed. Login denied.'}), 400

    except Exception as e:
        print(f"Error during login: {e}")
        return jsonify({'status': 'fail', 'message': 'Login failed. Please try again.'}), 500


@app.route('/products')
def products():
    return render_template('products.html')

@app.route('/calculate_total', methods=['POST'])
def calculate_total():
    """Calculate the total amount based on selected products."""
    try:
        products = request.get_json().get('products', [])
        
        # Calculate the total based on product prices and quantities
        total_amount = sum(Decimal(product['price']) * int(product.get('quantity', 1)) for product in products)
        
        # Store the total amount in the session for access in checkout and dashboard
        session['total_amount'] = str(total_amount)  # Store as a string for JSON compatibility
        
        return jsonify({'status': 'success', 'total_amount': str(total_amount)})
    except Exception as e:
        print(f"Error calculating total: {e}")
        return jsonify({'status': 'fail', 'message': 'Failed to calculate total amount.'}), 500

@app.route('/checkout')
def checkout():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login'))
    
    payment_methods = load_payment_methods_by_user_id(user_id)
    return render_template('checkout.html', payment_methods=payment_methods, user_id=user_id)

@app.route('/checkout_verification', methods=['POST'])
def checkout_verification():
    try:
        user_id = request.form.get('user_id')
        face_data = request.form.get('face_data')

        # Decode the face image and verify it
        image = decode_image(face_data)
        if image is None or not verify_face(user_id, image):
            return jsonify({'status': 'fail', 'message': 'Face verification failed.'}), 400
        
        return jsonify({'status': 'success'})
    except Exception as e:
        print(f"Error during face verification at checkout: {e}")
        return jsonify({'status': 'fail', 'message': 'Verification failed. Please try again.'}), 500

@app.route('/payment_intent', methods=['POST'])
def create_payment_intent():
    """Create a Stripe payment intent for embedded checkout."""
    try:
        intent = stripe.PaymentIntent.create(
            amount=1000,  # Adjust amount as needed
            currency='usd',
            payment_method_types=['card'],
        )
        return jsonify({'client_secret': intent.client_secret})
    except Exception as e:
        print(f"Error creating payment intent: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/payment_success')
def payment_success():
    user_id = session.get('user_id')
    total_amount = session.get('total_amount', "0.00")

    if not user_id:
        return redirect(url_for('login'))

    # Create a new transaction entry
    transaction = {
        'user_id': user_id,
        'amount': total_amount,
        'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'status': 'Success'
    }

    # Initialize transactions list in session if not present
    if 'transactions' not in session:
        session['transactions'] = []

    # Append the new transaction
    session['transactions'].append(transaction)

    # Update the session to ensure changes are saved
    session.modified = True

    return render_template('payment_success.html')

@app.route('/dashboard')
def dashboard():
    user_id = session.get('user_id')
    
    if not user_id:
        return redirect(url_for('login'))
    
    # Retrieve all transactions and filter by the current user_id
    all_transactions = session.get('transactions', [])
    user_transactions = [t for t in all_transactions if t['user_id'] == user_id]

    # Calculate total amount spent by summing all user-specific transactions
    total_amount = sum(Decimal(transaction['amount']) for transaction in user_transactions)

    return render_template('dashboard.html', user_id=user_id, transactions=user_transactions, total_amount=str(total_amount))


if __name__ == "__main__":
    app.run(debug=True)
